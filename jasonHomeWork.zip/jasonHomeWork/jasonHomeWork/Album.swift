//
//  Album.swift
//  jasonHomeWork
//
//  Created by maher deeb on 10/06/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

class Album{
    
    var albumId = 0
    var albumTitle = ""
    var photos : [Photo] = []
    
    
    
}
