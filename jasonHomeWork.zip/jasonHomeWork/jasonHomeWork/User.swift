//
//  User.swift
//  jasonHomeWork
//
//  Created by maher deeb on 10/06/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

class User {
    
    var idNumber : Int?
    var name : String?
    var city : String?
    
    var albums : [Album] = []
    
    
}
