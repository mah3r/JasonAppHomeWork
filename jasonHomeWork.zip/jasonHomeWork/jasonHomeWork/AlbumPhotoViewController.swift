//
//  AlbumPhotoViewController.swift
//  jasonHomeWork
//
//  Created by maher deeb on 10/06/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class AlbumPhotoViewController: UIViewController, UICollectionViewDelegate , UICollectionViewDataSource  {
    
    @IBOutlet weak var albumPhotoCollectioView: UICollectionView!
    var albumPhotoRefresher : UIRefreshControl!
    var album : Album?
    var phtitle : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadAndRefreshData()
        albumPhotoRefresher = UIRefreshControl()
        albumPhotoRefresher.attributedTitle = NSAttributedString(string: "Pull To refresh")
        albumPhotoRefresher.addTarget(self, action: #selector(AlbumPhotoViewController.loadAndRefreshData), for: UIControlEvents.valueChanged)
        albumPhotoCollectioView.addSubview(albumPhotoRefresher)
        
        
        title = album?.albumTitle
        
    }
    func loadAndRefreshData(){
        album?.photos.removeAll()
        let userAlbumPhotoUrl = URL(string: "http://jsonplaceholder.typicode.com/photos?albumId=\(album!.albumId	)")
        let request = URLRequest(url: userAlbumPhotoUrl!)
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if data != nil && error == nil{
                let usersAlbumPhotosJson = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [[String:AnyObject]]
                if let usersAlbumPhotosJson = usersAlbumPhotosJson{
                    for userAlbumPhotosJson in usersAlbumPhotosJson{
                        let newPhoto = Photo()
                        newPhoto.photoTitle = (userAlbumPhotosJson ["title"] as! String)
                        newPhoto.photoUrl = (userAlbumPhotosJson ["url"] as! String)
                        newPhoto.photoThumbnailUrl = (userAlbumPhotosJson ["thumbnailUrl"] as! String)
                        self.album?.photos.append(newPhoto)
                    }
                    DispatchQueue.main.async {
                        self.albumPhotoCollectioView.reloadData()
                        self.albumPhotoRefresher.endRefreshing()
                    }
                }
            }
            }.resume()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (album?.photos.count)!
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let photosCell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageCollection", for: indexPath) as! imageCollectionViewCell
        
        if !(album?.photos.isEmpty)!{
            let photo = album?.photos[indexPath.row]
            
            photosCell.titlePhotoView.text = photo?.photoTitle
            let thumbnailUrlImage = URL(string: (album?.photos[indexPath.row].photoThumbnailUrl)!)
            let request = URLRequest(url: thumbnailUrlImage!)
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        
                        photosCell.albumPhotoView.image = image
                    }
                }
                }.resume()
        }
        return photosCell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let userAlbumPhotoViewController = segue.destination as! PhotoViewController
        let photo = album?.photos[(albumPhotoCollectioView.indexPathsForSelectedItems?.first?.row)!]
        userAlbumPhotoViewController.photo = photo
    }
    
    
}
