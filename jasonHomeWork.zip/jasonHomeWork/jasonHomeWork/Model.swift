//
//  Model.swift
//  jasonHomeWork
//
//  Created by maher deeb on 10/06/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

class Model{
    static var sharedInstance = Model()
    
    private init(){
        
        
    }
    var users : [User] = []
    
    
    
    
}
