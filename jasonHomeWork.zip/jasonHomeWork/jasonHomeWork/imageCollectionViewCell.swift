//
//  imageCollectionViewCell.swift
//  jasonHomeWork
//
//  Created by maher deeb on 09/06/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class imageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var albumPhotoView: UIImageView!
    @IBOutlet weak var titlePhotoView: UILabel!
    
    
}
