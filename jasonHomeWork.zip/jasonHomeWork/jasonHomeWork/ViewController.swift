//
//  ViewController.swift
//  jasonHomeWork
//
//  Created by maher deeb on 09/06/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource  {
    
    @IBOutlet weak var usersTableView: UITableView!
    
    var refresher : UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        loadAndRefreshData()
        refresher = UIRefreshControl()
        refresher.attributedTitle = NSAttributedString(string: "Pull To refresh")
        refresher.addTarget(self, action: #selector(ViewController.loadAndRefreshData), for: UIControlEvents.valueChanged)
        usersTableView.addSubview(refresher)
        
        title = "User's"
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func loadAndRefreshData(){
        Model.sharedInstance.users.removeAll()
        
        let userUrl = URL (string: "http://jsonplaceholder.typicode.com/users")!
        let request = URLRequest(url: userUrl)
        URLSession.shared.dataTask(with: request) { (data, respons, error) in
            if data != nil && error == nil{
                let usersJson = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [[String:AnyObject]]
                if let usersJson = usersJson{
                    for userJson in usersJson{
                        let newUser = User()
                        newUser.idNumber = userJson["id"] as? Int
                        newUser.name = userJson["name"] as? String
                        let adressJson = userJson["address"] as! [String:AnyObject]
                        newUser.city = adressJson["city"] as? String
                        
                        Model.sharedInstance.users.append(newUser)
                        
                    }
                    
                    DispatchQueue.main.async {
                        self.usersTableView.reloadData()
                        self.refresher.endRefreshing()
                    }
                }
                
            }
            }.resume()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Model.sharedInstance.users.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let userCell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! userTableViewCell
        
        if !Model.sharedInstance.users.isEmpty{
            let user = Model.sharedInstance.users[indexPath.row]
            
            userCell.idLabel?.text = "User Id : \(user.idNumber!)"
            userCell.nameLabel?.text = ("Name : " + user.name!)
            userCell.usernameLabel?.text = ("City : " + user.city!)
        }
        
        
        return userCell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "userSegue", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let userViewController = segue.destination as! AlbumViewController
        let selectedUser = Model.sharedInstance.users[usersTableView.indexPathForSelectedRow!.row]
        
        userViewController.user = selectedUser
    }
    
    
    
}

