//
//  AlbumViewController.swift
//  jasonHomeWork
//
//  Created by maher deeb on 10/06/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class AlbumViewController: UIViewController , UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var userAlbumTableView: UITableView!
    var albumsRefresher : UIRefreshControl!
    var user : User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadAndRefreshData()
        albumsRefresher = UIRefreshControl()
        albumsRefresher.attributedTitle = NSAttributedString(string: "Pull To refresh")
        albumsRefresher.addTarget(self, action: #selector(AlbumViewController.loadAndRefreshData), for: UIControlEvents.valueChanged)
        userAlbumTableView.addSubview(albumsRefresher)
        
        
        title = "User Album's"
        
    }
    func loadAndRefreshData(){
        user?.albums.removeAll()
        let userAlbumUrl = URL(string: "http://jsonplaceholder.typicode.com/albums?userId=\(user!.idNumber!)")
        let request = URLRequest(url: userAlbumUrl!)
        URLSession.shared.dataTask(with: request) { (data, respons, error) in
            if data != nil && error == nil{
                let usersAlbumJson = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [[String:AnyObject]]
                if let usersAlbumJson = usersAlbumJson{
                    for userAlbumJson in usersAlbumJson{
                        let newAlbum = Album()
                        newAlbum.albumId = (userAlbumJson["id"] as? Int)!
                        newAlbum.albumTitle = (userAlbumJson["title"] as? String)!
                        
                        
                        self.user?.albums.append(newAlbum)
                    }
                    
                    DispatchQueue.main.async {
                        self.userAlbumTableView.reloadData()
                        self.albumsRefresher.endRefreshing()
                    }
                }
                
            }
            }.resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (user?.albums.count)!
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let userAlbumCell = tableView.dequeueReusableCell(withIdentifier: "albumCell") as! albumTableViewCell
        
         if !(user?.albums.isEmpty)!{
        let album = user?.albums[indexPath.row]
        
        userAlbumCell.albumIdLabel.text = "Album Id : \(album!.albumId)"
        userAlbumCell.albumLabel.text = ("Album Title : " + (album?.albumTitle)!)
        }
        return userAlbumCell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "userSegue1", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let userAlbumViewController = segue.destination as! AlbumPhotoViewController
        let selectedUserAlbum = user?.albums[userAlbumTableView.indexPathForSelectedRow!.row]
        
        userAlbumViewController.album = selectedUserAlbum
    }
    
}
