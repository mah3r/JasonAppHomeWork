//
//  PhotoViewController.swift
//  jasonHomeWork
//
//  Created by maher deeb on 10/06/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class PhotoViewController: UIViewController , UIScrollViewDelegate {
    
    @IBOutlet weak var photoName: UILabel!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var photoScrollView: UIScrollView!
    
    var photo : Photo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.photoScrollView.minimumZoomScale = 1.0
        self.photoScrollView.maximumZoomScale = 6.0
        
        photoName.text = photo?.photoTitle
        
        let userAlbumPhotoUrl = URL(string: (photo?.photoUrl)! )
        let request = URLRequest(url: userAlbumPhotoUrl!)
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if data != nil {
                let image = UIImage(data: data!)
                DispatchQueue.main.async {
                    self.photoImageView.image = image
                }
            }
            }.resume()
        
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return self.photoImageView
    }
    
}
